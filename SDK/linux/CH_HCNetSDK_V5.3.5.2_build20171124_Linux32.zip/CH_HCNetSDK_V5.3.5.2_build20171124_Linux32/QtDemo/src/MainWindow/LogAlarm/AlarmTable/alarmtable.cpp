#include "alarmtable.h"

AlarmTable::AlarmTable(QWidget *parent)
    : QWidget(parent)
{
	ui.setupUi(this);
}

AlarmTable::~AlarmTable()
{

}
