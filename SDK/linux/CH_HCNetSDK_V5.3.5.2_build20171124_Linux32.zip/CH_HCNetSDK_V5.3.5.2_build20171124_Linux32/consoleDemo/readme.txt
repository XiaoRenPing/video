   Before you build the source code, please copy library files to the direct "lib".
   For example, 
   (1)If you build linux32 project, you need copy library(.so) to the direct "./linux32/lib/".
   (2)Go to the direct "./linux32/proj", then make.
  