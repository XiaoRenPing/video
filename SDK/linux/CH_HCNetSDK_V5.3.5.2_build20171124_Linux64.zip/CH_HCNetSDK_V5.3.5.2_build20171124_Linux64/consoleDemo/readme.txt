   Before you build the source code, please copy library files to the direct "lib".
   For example, 
   (1)If you build linux64 project, you need copy library(.so) to the direct "./linux64/lib/".
   (2)Go to the direct "./linux64/proj", then make.
  