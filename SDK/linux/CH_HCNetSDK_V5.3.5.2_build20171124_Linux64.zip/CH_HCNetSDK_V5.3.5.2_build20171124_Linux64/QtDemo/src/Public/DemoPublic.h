#ifndef _DEMOPUBLIC_H_
#define _DEMOPUBLIC_H_

#if defined(_WIN32)
#include <Windows.h>
#pragma warning( disable : 4996)
#else
#endif

#include "HCNetSDK.h"
#include "PlayM4.h"

#define DEMO_IP_MAX_LEN 17

#endif